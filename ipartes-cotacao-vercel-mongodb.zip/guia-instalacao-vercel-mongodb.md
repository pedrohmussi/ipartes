# Guia de Instalação do Sistema de Cotação IPARTES no Vercel com MongoDB Atlas

Este guia detalhado irá te ajudar a instalar e configurar o Sistema de Cotação IPARTES na plataforma Vercel, utilizando o MongoDB Atlas como banco de dados. Não se preocupe se você não tem conhecimentos técnicos avançados, este guia foi feito para ser o mais simples e direto possível.

## Por que Vercel e MongoDB Atlas?

O Vercel é uma plataforma de hospedagem que oferece um serviço rápido, confiável e, o mais importante, **gratuito para projetos pessoais**, sem a necessidade de um servidor dedicado. Ele é ideal para aplicações como o Sistema de Cotação IPARTES, pois mantém sua aplicação sempre online e acessível.

O MongoDB Atlas é um serviço de banco de dados em nuvem que oferece uma maneira fácil e gratuita de armazenar seus dados de forma persistente. Isso significa que todos os fornecedores que você cadastrar no sistema ficarão salvos de forma segura e não serão perdidos, mesmo que a aplicação fique inativa por um tempo.

Juntos, Vercel e MongoDB Atlas garantem que seu sistema esteja sempre disponível e que seus dados estejam seguros.

## O que você vai precisar:

1.  **Uma conta Vercel:** Se você ainda não tem, pode criar uma gratuitamente usando sua conta GitHub, GitLab ou Bitbucket.
2.  **Uma conta MongoDB Atlas:** Também é gratuita e pode ser criada com sua conta Google ou GitHub.
3.  **Os arquivos do sistema:** Você já possui um arquivo ZIP com todos os arquivos necessários. Certifique-se de descompactá-lo em uma pasta no seu computador.

Vamos começar!




## Passo 1: Configurar o MongoDB Atlas

O MongoDB Atlas será o local onde seus dados de fornecedores serão armazenados. Siga estes passos para configurá-lo:

1.  **Acesse o MongoDB Atlas:** Vá para [cloud.mongodb.com](https://cloud.mongodb.com/) e faça login na sua conta. Se for sua primeira vez, siga as instruções para criar uma nova organização e projeto.

2.  **Crie um novo Cluster:**
    *   Na página inicial do Atlas, clique em `Build a Database`.
    *   Escolha a opção `M0 Free` (gratuita).
    *   Selecione um provedor de nuvem (AWS, Google Cloud ou Azure) e uma região próxima a você para melhor desempenho. Por exemplo, `AWS / N. Virginia (us-east-1)`.
    *   Dê um nome ao seu cluster (ex: `ipartes-cotacao-cluster`) e clique em `Create Cluster`.

3.  **Configure o Acesso à Rede:**
    *   Enquanto o cluster está sendo provisionado (pode levar alguns minutos), vá para a seção `Network Access` no menu lateral esquerdo.
    *   Clique em `Add IP Address`.
    *   Selecione `Allow Access from Anywhere` e clique em `Confirm`. Isso permite que sua aplicação no Vercel se conecte ao banco de dados. **Atenção:** Para maior segurança em um ambiente de produção, você deveria restringir os IPs, mas para este guia simplificado, "Allow Access from Anywhere" é suficiente.

4.  **Crie um Usuário de Banco de Dados:**
    *   Vá para a seção `Database Access` no menu lateral esquerdo.
    *   Clique em `Add New Database User`.
    *   Escolha `Password` como método de autenticação.
    *   Crie um `Username` (ex: `ipartes_user`) e uma `Password` forte. **Anote este usuário e senha**, você precisará deles mais tarde.
    *   Em `Database User Privileges`, selecione `Read and write to any database`.
    *   Clique em `Add User`.

5.  **Obtenha a String de Conexão:**
    *   Volte para a página `Databases` (clique em `Database` no menu lateral esquerdo).
    *   Quando seu cluster estiver pronto, clique no botão `Connect`.
    *   Selecione `Connect your application`.
    *   Escolha `Node.js` e a versão mais recente.
    *   **Copie a string de conexão** que será exibida. Ela será algo parecido com:
        `mongodb+srv://<username>:<password>@cluster0.xxxxxxx.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0`
    *   **Substitua `<username>` pelo usuário que você criou** (ex: `ipartes_user`) e **`<password>` pela senha que você definiu**. **Anote esta string de conexão modificada**, ela é crucial para o próximo passo.

Parabéns! Seu banco de dados MongoDB Atlas está configurado e pronto para ser usado. Agora vamos para o Vercel.




## Passo 2: Deploy no Vercel

Agora que seu banco de dados está pronto, vamos fazer o deploy da aplicação no Vercel.

1.  **Prepare os arquivos do sistema:** Certifique-se de que você descompactou o arquivo ZIP que eu te enviei em uma pasta no seu computador. Esta pasta contém todos os arquivos do projeto.

2.  **Acesse o Vercel:** Vá para [vercel.com](https://vercel.com/) e faça login na sua conta.

3.  **Importe seu Projeto:**
    *   No dashboard do Vercel, clique em `Add New...` e depois em `Project`.
    *   Selecione `Import Git Repository` se você já tem o código em um repositório (GitHub, GitLab, Bitbucket). Se não, você pode usar a opção `Deploy a Git Repository` e seguir as instruções para conectar seu repositório ou fazer o upload da pasta diretamente.
    *   **Recomendado:** Crie um repositório privado no GitHub (ou similar) e faça o upload da pasta do projeto para lá. Isso facilita muito o deploy e as atualizações futuras.
    *   Após importar o repositório, o Vercel detectará automaticamente que é um projeto Node.js.

4.  **Configure as Variáveis de Ambiente:**
    *   Antes de fazer o deploy, você precisará configurar as variáveis de ambiente para que sua aplicação possa se conectar ao MongoDB Atlas.
    *   Na tela de configuração do projeto no Vercel, vá para a seção `Environment Variables`.
    *   Adicione as seguintes variáveis:
        *   `MONGODB_URI`: Cole a string de conexão do MongoDB Atlas que você modificou no Passo 1 (aquela com seu usuário e senha).
        *   `DB_NAME`: `ipartes_cotacao` (este é o nome do banco de dados que a aplicação espera).
        *   `COLLECTION_NAME`: `suppliers` (este é o nome da coleção onde os fornecedores serão armazenados).
        *   `OPENAI_API_KEY`: Você pode usar a chave de API do OpenAI que eu te forneci anteriormente, ou gerar uma nova no site da OpenAI. Esta chave é usada para a funcionalidade de geração de email e busca de fornecedores via ChatGPT.

    *   Certifique-se de que os nomes das variáveis (`MONGODB_URI`, `DB_NAME`, `COLLECTION_NAME`, `OPENAI_API_KEY`) estejam exatamente como escrito, pois a aplicação os espera assim.

5.  **Faça o Deploy:**
    *   Após configurar as variáveis de ambiente, clique em `Deploy`.
    *   O Vercel irá construir e implantar sua aplicação. Este processo pode levar alguns minutos.
    *   Uma vez concluído, você verá uma mensagem de sucesso e um link para sua aplicação. Este será o seu link permanente!

## Passo 3: Acessando e Usando o Sistema

1.  **Acesse o Link:** Clique no link fornecido pelo Vercel após o deploy. Ele será algo como `https://seu-projeto.vercel.app`.
2.  **Teste o Cadastro de Fornecedores:** Vá para a página de cadastro de fornecedores e adicione alguns. Verifique se eles são salvos e se aparecem na lista.
3.  **Teste a Geração de Email e Busca de Fornecedores:** Use a funcionalidade principal do sistema para gerar emails e buscar fornecedores para produtos específicos.

Parabéns! Você tem agora o Sistema de Cotação IPARTES funcionando de forma permanente no Vercel, com todos os seus dados salvos no MongoDB Atlas.

Se tiver qualquer dúvida ou encontrar alguma dificuldade, não hesite em me perguntar. Estou aqui para ajudar!


